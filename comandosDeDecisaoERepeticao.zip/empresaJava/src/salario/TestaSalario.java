package salario;
import java.util.Scanner;  
public class TestaSalario {
	
		public static void main(String[] args) {
	    
		Scanner input = new Scanner(System.in); 
		double salario;	
		double valorAumento;
		System.out.println("Digite o salario atual do funcionário:");

	    salario = input.nextDouble(); 
	    if(salario <= 1200) {
	    	valorAumento = salario * 0.1;
	    	salario *= 1.1;
	    	
	    	System.out.println("O valor do novo salário é de : " + salario );
	    	System.out.println("O valor do aumento foi de R$" + valorAumento);
	    }
	    else {
	    	valorAumento = salario * 0.05;
	    	salario *= 1.05;
	    	
	    	System.out.println(" O valor do novo salário é de R$" + salario);
	    	System.out.println("O valor do aumento foi de R$" + valorAumento);
	    }
	   
	  }
}
