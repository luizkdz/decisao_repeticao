package salario;

import java.util.Scanner;

public class Radar {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Digite os valores das velocidades:");
        
        double[] velCarros = 	new double[5];
        int multas = 0;
        int numCarros = 5;
        for(int i = 0; i < numCarros; i++) {
            velCarros[i] = input.nextDouble();
            
            if(velCarros[i] > 60) {
                multas++;
            }
        }
        
        int valorMulta = 150;
        double totalMulta = valorMulta * multas;

        System.out.println("A quantidade de veículos acima de 60km/h foi de " + multas);
        System.out.println("O valor total das multas foi de " + totalMulta);

    }

}

