package salario;

import java.util.Scanner;

public class Notas {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		double nota1, nota2, nota3, media;
		System.out.println("Digite o valor das notas:");
		nota1 = input.nextDouble();
		nota2 = input.nextDouble();
		nota3 = input.nextDouble();
		
		media =(nota1 + nota2 + nota3)/3;
		if((nota1 > 10 || nota1 < 0) || nota2 > 10 || nota2 < 0 || nota3>10 || nota3 < 0) {
			throw new IllegalArgumentException("Digite um valor válido");
		}
		if(media < 4.0) {
			System.out.println("Reprovado");
		}
		else if(media >= 4.0 && media < 6.0 ) {
			System.out.println("Exame especial");
		}
		else {
			System.out.println("Aprovado");
		}
		
	}
}
